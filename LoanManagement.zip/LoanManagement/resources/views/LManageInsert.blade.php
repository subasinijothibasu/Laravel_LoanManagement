<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lender Approval Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #E7FAF3;
            margin: 0;
            padding: 0;
        }
        form {
            width: 50%;
            margin: 50px auto;
            background: #A9A9A9;
            padding: 20px;
            border-radius: 4px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
        }
        label {
            display: block;
            margin: 10px 0;
        }
        select {
            width: calc(100% - 20px);
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button.approve {
            background: #4CAF50;
            color: white;
        }
        button.reject {
            background: #e74c3c;
            color: white;
        }
        button:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>

<form action="/create2" method="post">
    <h1>Loan Approval</h1>
    @csrf

    <label for="applicationId">Application ID:</label>
    <input type="text" id="applicationId" name="applicationId" required>

    <label for="applicationName">Application Name:</label>
    <input type="text" id="applicationName" name="applicationName" required>

    <label for="loanType">Loan Type :</label>
    <input type="t" id="loanType" name="loanType" required>

    <label for="approvalStatus">Approval Status:</label>
    <select id="approvalStatus" name="approvalStatus" required>
        <option value="approved">Approved</option>
        <option value="rejected">Rejected</option>
    </select>

    <label for="comments">Comments (optional):</label>
    <textarea id="comments" name="comments" rows="4"></textarea>

    <button type="submit">Submit</button>
</form>

</body>
</html>
