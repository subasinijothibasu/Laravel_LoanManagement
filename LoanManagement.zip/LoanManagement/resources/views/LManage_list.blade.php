<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view lender records</title>
    <style>
        body{
            font-size: 20px;
            background-color:#BCC8EC;
            
        }
        table{
            position: relative;
            top: 200px;
            border-collapse: collapse;
            margin: 0 auto;
            width: 200px;
            height: auto;
            border: 1px solid black;
        }
        th,td{
            padding: 10px;
            border: 10pxpx solid black;
        }
        tr:nth-child(even){
            background-color: dodgerblue;
        }
        tr:nth-child(even):hover{
            background-color: white;
        }
        </style>
</head>
<body>
    <table>
        <tr>
            <th>ID</th>
            <th>Applicantion ID</th>
            <th>Application Name</th>
            <th>Loan type</th>
            <th>Approval status</th>
            <th>Comments</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        @foreach ($lmanagements as $_lmanagement)
        <tr>
            <td>{{ $_lmanagement->applicationId }}</td>
            <td>{{ $_lmanagement->applicationName }}</td>
            <td>{{ $_lmanagement->loanType }}</td>
            <td>{{ $_lmanagement->approvalStatus}}</td>
            <td>{{ $_lmanagement->comments }}</td>

            <td><a href="edit2/{{ $_lmanagement->id }}"> Edit</a></td>
            <td><a href="delete2/{{ $_lmanagement->id }}">Delete</a></td>
            
        </tr>
        @endforeach
    </table>
    <a href = "{{ route('LManageInsert') }}">
        <button class = "add-a-button">ADD LOAN </button>
    </a>
    <a href = "{{ route('Landingpage') }}">
        <button class = "add-a-button">GO BACK </button>
    </a>

</body>
</html>