<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view borrower records</title>
    <style>
        body{
            font-size: 20px;
            background-color:#BCC8EC;
            
        }
        table{
            position: relative;
            top: 200px;
            border-collapse: collapse;
            margin: 0 auto;
            width: 200px;
            height: auto;
            border: 1px solid black;
        }
        th,td{
            padding: 10px;
            border: 10pxpx solid black;
        }
        tr:nth-child(even){
            background-color: dodgerblue;
        }
        tr:nth-child(even):hover{
            background-color: white;
        }
        </style>
</head>
<body>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>DOB</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Address</th>
            <th>Phone Number</th>
            <th>Account number</th>
            <th>Qualification</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        @foreach ($borrowers as $borrower)
        <tr>
            <td>{{ $borrower->id }}</td>
            <td>{{ $borrower->name }}</td>
            <td>{{ $borrower->dob }}</td>
            <td>{{ $borrower->age}}</td>
            <td>{{ $borrower->gender }}</td>
            <td>{{ $borrower->address }}</td>
            <td>{{ $borrower->phone }}</td>
            <td>{{ $borrower->account }}</td>
            <td>{{ $borrower->qualification }}</td>
            <td><a href="edit/{{ $borrower->id }}"> Edit</a></td>
            <td><a href="delete/{{ $borrower->id }}">Delete</a></td>
            
        </tr>
        @endforeach
    </table>
    <a href = "{{ route('BorrowerInsertform') }}">
        <button class = "add-a-button">ADD BORROWER </button>
    </a>
    <a href = "{{ route('Landingpage') }}">
        <button class = "add-a-button">GO BACK </button>
    </a>

</body>
</html>