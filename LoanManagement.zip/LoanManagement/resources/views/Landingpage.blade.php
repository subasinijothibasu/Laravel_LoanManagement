<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan Management System</title>
    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            letter-spacing: 1.3px;
            overflow: hidden;
            background-image: url('1.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;  
            background-size: cover;
            color: white;
        }
        header {
            width: 100%;
            height: 60px;
            background-color: #E59866;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 0px;
            box-shadow: 0 5px 5px rgba(0, 0, 0, 0.2);
        }
        h2 {
            margin: 0;
        }
        nav ul {
            list-style-type: none;
            display: flex;
        }
        nav li {
            margin-left: 20px;
        }
        nav a {
            text-decoration: none;
            color: white;
            font-weight: bold;
            font-size: 1.2em;
        }
        .welcome {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: calc(100vh - 60px);
        }
        marquee {
            color: black;
            font-size: 4vw;
            font-weight: 800;
            width: 100%;
            padding: 10px 0;
            background-color: lightblue;
        }
        .buttons-container {
            display: flex;
            justify-content: space-evenly;
            margin-top: 20px;
        }
        .button {
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            font-size: 1.2em;
            cursor: pointer;
        }
        .lender-button {
            background-color: #3498db;
            color: white;
        }
        .borrower-button {
            background-color: #27ae60;
            color: white;
        }
    </style>
</head>
<body>
    <header>
        <div class="staff">
            <h2>LOAN MANAGEMENT SYSTEM</h2>
        </div>
        <nav>
            <ul>
                <li><a href="/Landingpage">Home</a></li>
                <li><a href="/LenderInsertform">Lender</a></li>
                <li><a href="/BorrowerInsertform">Borrower</a></li>
            </ul>
        </nav>
    </header>

    <div class="welcome">
        <marquee behavior="scroll" direction="left" scrollamount="20">Welcome to Loan Management System</marquee>
        
        <div class="buttons-container">
            <a href="/LManageInsert" class="LManageInsert">Manage Loans</a>
        </div>
    </div>
</body>
</html>
