<!DOCTYPE html>

<htmlender>
    <head>
        <title>Lender Registration | Edit</title> 
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 0;
            }
            h1{
                text-align: center;
            }
            
            form {
                width: 300px; 
                margin: 0 auto; 
                background-color: #fff; 
                border: 1px solid #ccc; 
                padding: 20px; 
                border-radius: 5px; 
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            }
            input[type="submit"]:hover { 
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
        <form action="/edit2/{{ $_lmanagement[0]->id }}" method="post"> 
            @csrf
            <h1>Edit form</h1>
            <table>
                <tr>
                    <td>Application ID</td>
                    <td><input type="text" name="applicationId" value="{{ $_lmanagement[0]->applicationId}}" /></td>
                </tr>

                <tr>
                    <td>Application Name</td>
                    <td><input type="text" name="applicationName" value="{{ $_lmanagement[0]->applicationName }}" /></td>
                </tr>

                <tr>
                    <td>Loan Type</td>
                    <td>
                        <select name="loanType">
                            <option value="personal">Personal Loan</option>
                            <option value="business">Business Loan</option>
                            <option value="mortgage">Mortgage Loan</option>
                            <option value="mortgage">Educational Loan</option>
                            <option value="mortgage">Agriculture Loan</option>
                            <option value="mortgage">Gold Loan</option>
                            <option value="mortgage">Home Loan</option>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <td>Approval Status </td>
                    <td><input type="text" name="approvalStatus" value="{{ $_lmanagement[0]->approvalStatus }}" /></td>
                </tr>

                <tr>
                    <td> Comments </td>
                    <td><input type="text" name="comments" value="{{ $_lmanagement[0]->comments }}" /></td>
                </tr>
                
               

                

                <tr>
                    <td colenderspan="2">
                        <input type="submit" value="Update Loan" />
                    </td>
                </tr>
             </table>
        </form>
    </body>
</html>