<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view lender records</title>
    <style>
        body{
            font-size: 20px;
            background-color:#BCC8EC;
            
        }
        table{
            position: relative;
            top: 300px;
            border-collapse: collapse;
            margin: 0 auto;
            width: 50px;
            height: auto;
            border: 1px solid black;
        }
        th,td{
            padding: 10px;
            border: 10pxpx solid black;
        }
        tr:nth-child(even){
            background-color: dodgerblue;
        }
        tr:nth-child(even):hover{
            background-color: white;
        }
        </style>
</head>
<body>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>DOB</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Address</th>
            <th>Phone Number</th>
            <th>Aadhar number</th>
            <th>Bank</th>
            <th>Account Number</th>
            <th>Email</th>
            <th>Loan type</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        @foreach ($lenders as $_lender)
        <tr>
            <td>{{ $_lender->id }}</td>
            <td>{{ $_lender->name }}</td>
            <td>{{ $_lender->dob }}</td>
            <td>{{ $_lender->age}}</td>
            <td>{{ $_lender->gender }}</td>
            <td>{{ $_lender->address }}</td>
            <td>{{ $_lender->phone }}</td>
            <td>{{ $_lender->aadhar }}</td>
            <td>{{ $_lender->bank }}</td>
            <td>{{ $_lender->account }}</td>
            <td>{{ $_lender->email }}</td>
            <td>{{ $_lender->loanType }}</td>
            <td><a href="edit1/{{ $_lender->id }}"> Edit</a></td>
            <td><a href="delete1/{{ $_lender->id }}">Delete</a></td>
            
        </tr>
        @endforeach
    </table>
    <a href = "{{ route('LenderInsertform') }}">
        <button class = "add-a-button">ADD LENDER </button>
    </a>
    <a href = "{{ route('Landingpage') }}">
        <button class = "add-a-button">GO BACK </button>
    </a>

</body>
</html>