<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class LenderController extends Controller
{
    public function LenderInsertform(){
        return view('LenderInsertform');
    }
    public function insert1(Request $request){
        $name = $request->input('name');
        $dob = $request->input('dob');
        $age = $request->input('age');
        $gender = $request->input('gender');
        $address = $request->input('address');
        $phone = $request->input('phone');
        $aadhar = $request->input('aadhar');
        $bank = $request->input('bank');
        $account = $request->input('account');
        $email = $request->input('email');
        $loanType = $request->input('loanType');
        
        DB::insert("insert into _lender(name,dob,age,gender,address,phone,aadhar,bank,account,email,loanType) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [$name,$dob,$age,$gender,$address,$phone,$aadhar,$bank,$account,$email,$loanType]);
        return 'Record inserted successfully!  <a href="/view-records-_lender">Click here to go back</a>';
    }

    public function Lender_list(){
        $lenders= DB::select("select * from _lender");
        return view('Lender_list',['lenders'=>$lenders]);
    }
    public function edit1($id){
        $_lender = DB::select("select * from _lender where id=?", [$id]);
        return view('Lender_edit',['_lender'=>$_lender]);
    }

    public function update1(Request $request,$id){
        $name = $request->input('name');
        $dob = $request->input('dob');
        $age = $request->input('age');
        $gender = $request->input('gender');
        $address = $request->input('address');
        $phone = $request->input('phone');
        $aadhar = $request->input('aadhar');
        $bank = $request->input('bank');
        $account = $request->input('account');
        $email = $request->input('email');
        $loanType = $request->input('loanType');
        DB::update("update _lender set name=?,dob=?,age=?,gender=?,address=?,phone=?,aadhar=?,bank=?,account=?,email=?,loanType=? where id=?",[$name,$dob,$age,$gender,$address,$phone,$aadhar,$bank,$account,$email,$loanType,$id]);
        return 'Record updated successfully!  <a href="/view-records-_lender">Click here to go back</a>';
       
    }
    
    public function delete1($id){
        DB::delete("delete from _lender where id=?",[$id]);
        return 'Record deleted successfully!  <a href="/view-records-_lender">Click here to go back</a>';
    }
}
