<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class LManageController extends Controller
{
    public function LManageInsert(){
        return view('LManageInsert');
    }
    public function insert2(Request $request){
        $applicationId = $request->input('applicationId');
        $applicationName = $request->input('applicationName');
        $loanType = $request->input('loanType');
        $approvalStatus = $request->input('approvalStatus');
        $comments = $request->input('comments');

        DB::insert("insert into _lmanagement(applicationId,applicationName,loanType,approvalStatus,comments) values(?, ?, ?, ?, ?)", [$applicationId,$applicationName,$loanType,$approvalStatus,$comments]);
        return 'Record inserted successfully!  <a href="/view-records-_lmanagement">Click here to go back</a>';
    }

    public function LManage_list(){
        $lmanagements= DB::select("select * from _lmanagement");
        return view('LManage_list',['lmanagements'=>$lmanagements]);
    }
    public function edit2($id){
        $_lmanagement = DB::select("select * from _lmanagement where id=?", [$id]);
        return view('LManage_edit',['_lmanagement'=>$_lmanagement]);
    }

    public function update2(Request $request,$id){
        $applicationId = $request->input('applicationId');
        $applicationName = $request->input('applicationName');
        $loanType = $request->input('loanType');
        $approvalStatus = $request->input('approvalStatus');
        $comments = $request->input('comments');
        DB::update("update _lmanagement set applicationId=?,applicationName=?,loanType=?,approvalStatus=?,comments=? where id=?",[$applicationId,$applicationName,$loanType,$approvalStatus,$comments,$id]);
        return 'Record updated successfully!  <a href="/view-records-_lmanagement">Click here to go back</a>';
       
    }
    
    public function delete2($id){
        DB::delete("delete from _lmanagement where id=?",[$id]);
        return 'Record deleted successfully!  <a href="/view-records-_lmanagement">Click here to go back</a>';
    }
}
