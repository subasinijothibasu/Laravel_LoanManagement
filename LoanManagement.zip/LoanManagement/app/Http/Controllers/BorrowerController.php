<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class BorrowerController extends Controller
{
    public function BorrowerInsertform(){
        return view('BorrowerInsertform');
    }
    public function insert(Request $request){
        $name = $request->input('name');
        $dob = $request->input('dob');
        $age = $request->input('age');
        $gender = $request->input('gender');
        $address = $request->input('address');
        $phone = $request->input('phone');
        $account = $request->input('account');
        $qualification = $request->input('qualification');
        
        DB::insert("insert into borrower(name,dob,age,gender,address,phone,account,qualification) values(?, ?, ?, ?, ?, ?, ?, ?)", [$name,$dob,$age,$gender,$address,$phone,$account,$qualification]);
        return 'Record inserted successfully!  <a href="/view-records-borrower">Click here to go back</a>';
    }

    public function BorrowerList(){
        $borrowers= DB::select("select * from borrower");
        return view('BorrowerList',['borrowers'=>$borrowers]);
    }
    public function edit($id){
        $borrower = DB::select("select * from borrower where id=?", [$id]);
        return view('Borroweredit',['borrower'=>$borrower]);
    }

    public function update(Request $request,$id){
        $name = $request->input('name');
        $dob = $request->input('dob');
        $age = $request->input('age');
        $gender = $request->input('gender');
        $address = $request->input('address');
        $phone = $request->input('phone');
        $account = $request->input('account');
        $qualification = $request->input('qualification');
        DB::update("update borrower set name=?,dob=?,age=?,gender=?,address=?,phone=?,account=?,qualification=? where id=?",[$name,$dob,$age,$gender,$address,$phone,$account,$qualification,$id]);
        return 'Record updated successfully!  <a href="/view-records-borrower">Click here to go back</a>';
       
    }
    
    public function delete($id){
        DB::delete("delete from borrower where id=?",[$id]);
        return 'Record deleted successfully!  <a href="/view-records-borrower">Click here to go back</a>';
    }
}
