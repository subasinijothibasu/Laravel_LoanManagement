<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view lender records</title>
    <style>
        body{
            font-size: 20px;
            background-color:#BCC8EC;
            
        }
        table{
            position: relative;
            top: 300px;
            border-collapse: collapse;
            margin: 0 auto;
            width: 50px;
            height: auto;
            border: 1px solid black;
        }
        th,td{
            padding: 10px;
            border: 10pxpx solid black;
        }
        tr:nth-child(even){
            background-color: dodgerblue;
        }
        tr:nth-child(even):hover{
            background-color: white;
        }
        </style>
</head>
<body>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>DOB</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Address</th>
            <th>Phone Number</th>
            <th>Aadhar number</th>
            <th>Bank</th>
            <th>Account Number</th>
            <th>Email</th>
            <th>Loan type</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        <?php $__currentLoopData = $lenders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_lender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($_lender->id); ?></td>
            <td><?php echo e($_lender->name); ?></td>
            <td><?php echo e($_lender->dob); ?></td>
            <td><?php echo e($_lender->age); ?></td>
            <td><?php echo e($_lender->gender); ?></td>
            <td><?php echo e($_lender->address); ?></td>
            <td><?php echo e($_lender->phone); ?></td>
            <td><?php echo e($_lender->aadhar); ?></td>
            <td><?php echo e($_lender->bank); ?></td>
            <td><?php echo e($_lender->account); ?></td>
            <td><?php echo e($_lender->email); ?></td>
            <td><?php echo e($_lender->loanType); ?></td>
            <td><a href="edit1/<?php echo e($_lender->id); ?>"> Edit</a></td>
            <td><a href="delete1/<?php echo e($_lender->id); ?>">Delete</a></td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href = "<?php echo e(route('LenderInsertform')); ?>">
        <button class = "add-a-button">ADD LENDER </button>
    </a>
    <a href = "<?php echo e(route('Landingpage')); ?>">
        <button class = "add-a-button">GO BACK </button>
    </a>

</body>
</html><?php /**PATH C:\Users\NANDINI JOTHIBASU\LoanManagement\resources\views/Lender_list.blade.php ENDPATH**/ ?>