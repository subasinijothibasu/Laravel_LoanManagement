<!DOCTYPE htmlender>

<htmlender>
    <head>
        <title>Lender Registration | Edit</title> 
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 0;
            }
            h1{
                text-align: center;
            }
            
            form {
                width: 300px; 
                margin: 0 auto; 
                background-color: #fff; 
                border: 1px solid #ccc; 
                padding: 20px; 
                border-radius: 5px; 
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            }
            input[type="submit"]:hover { 
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
        <form action="/edit1/<?php echo e($_lender[0]->id); ?>" method="post"> 
            <?php echo csrf_field(); ?>
            <h1>Edit form</h1>
            <table>
                <tr>
                    <td>Name</td>
                    <td><input type="text" name="name" value="<?php echo e($_lender[0]->name); ?>" /></td>
                </tr>

                <tr>
                    <td>DOB</td>
                    <td><input type="date" name="dob" value="<?php echo e($_lender[0]->dob); ?>" /></td>
                </tr>

                <tr>
                    <td>Age</td>
                    <td><input type="text" name="age" value="<?php echo e($_lender[0]->age); ?>" /></td>
                </tr>
                
                <tr>
                    <td>Gender </td>
                    <td><input type="text" name="gender" value="<?php echo e($_lender[0]->gender); ?>" /></td>
                </tr>

                <tr>
                    <td> Address </td>
                    <td><input type="text" name="address" value="<?php echo e($_lender[0]->address); ?>" /></td>
                </tr>
                
                <tr>
                    <td>Phone Number </td>
                    <td><input type="number" name="phone" value="<?php echo e($_lender[0]->phone); ?>" /></td>
                </tr>

                <tr>
                    <td>Aadhar Number </td>
                    <td><input type="number" name="aadhar" value="<?php echo e($_lender[0]->aadhar); ?>" /></td>
                </tr>

                <tr>
                    <td>Bank </td>
                    <td><input type="text" name="bank" value="<?php echo e($_lender[0]->bank); ?>" /></td>
                </tr>

                <tr>
                    <td>Account Number </td>
                    <td><input type="number" name="account" value="<?php echo e($_lender[0]->account); ?>" /></td>
                </tr>

                <tr>
                    <td>Email </td>
                    <td><input type="text" name="email" value="<?php echo e($_lender[0]->email); ?>" /></td>
                </tr>
                

                <tr>
                    <td>Loan Type</td>
                    <td>
                        <select name="loanType">
                            <option value="personal">Personal Loan</option>
                            <option value="business">Business Loan</option>
                            <option value="mortgage">Mortgage Loan</option>
                            <option value="mortgage">Educational Loan</option>
                            <option value="mortgage">Agriculture Loan</option>
                            <option value="mortgage">Gold Loan</option>
                            <option value="mortgage">Home Loan</option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td colenderspan="2">
                        <input type="submit" value="Update Lender" />
                    </td>
                </tr>
             </table>
        </form>
    </body>
</htmlender><?php /**PATH C:\Users\NANDINI JOTHIBASU\LoanManagement\resources\views/Lender_edit.blade.php ENDPATH**/ ?>