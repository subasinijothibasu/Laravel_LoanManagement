<!DOCTYPE html>
<html>
<head>
    <title>Lender Information Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #E7FAF3;
            margin: 0;
            padding: 0;
        }
        form {
            width: 30%;
            margin: 50px auto;
            background: #A9A9A9;
            padding: 10px;
            border-radius: 4px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
        }
        table {
            width: 100%;
        }
        input[type="text"],
        input[type="email"],
        input[type="number"],
        input[type="date"] {
            width: calc(100% - 20px);
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        select {
            width: calc(100% - 20px);
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 4px;
            background: #4CAF50;
            color: white;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background: #45a049;
        }
    </style>
</head>
<body>

<form action="/create1" method="post">
    <h1>Lender form</h1>
    <?php echo csrf_field(); ?>
    <table>
        <tr>
            <td> Lender Name</td>
            <td><input type="text" name="name"/></td>
        </tr>
        <tr>
            <td>DOB</td>
            <td><input type="date" name="dob"/></td>
        </tr>
        <tr>
            <td>Age</td>
            <td><input type="number" name="age"/></td>
        </tr>
        <tr>
            <td>Gender</td>
            <td><input type="text" name="gender"/></td>
        </tr>
        <tr>
            <td>Address</td>
            <td><input type="text" name="address"/></td>
        </tr>
        <tr>
            <td>Phone</td>
            <td><input type="number" name="phone"/></td>
        </tr>
        <tr>
            <td>Aadhar No</td>
            <td><input type="number" name="aadhar"/></td>
        </tr>
        <tr>
            <td>Bank</td>
            <td><input type="text" name="bank"/></td>
        </tr>
        <tr>
            <td>Account No</td>
            <td><input type="number" name="account"/></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><input type="text" name="email"/></td>
        </tr>
        <tr>
            <td>Loan Type</td>
            <td>
                <select name="loanType">
                    <option value="personal">Personal Loan</option>
                    <option value="business">Business Loan</option>
                    <option value="mortgage">Mortgage Loan</option>
                    <option value="mortgage">Educational Loan</option>
                    <option value="mortgage">Agriculture Loan</option>
                    <option value="mortgage">Gold Loan</option>
                    <option value="mortgage">Home Loan</option>
                </select>
            </td>
        </tr>
        <tr>
            <td colspan='2'>
                <input type="submit" value="Submit" />
            </td>
        </tr>
    </table>
</form>

</body>
</html>
<?php /**PATH C:\Users\NANDINI JOTHIBASU\LoanManagement\resources\views/LenderInsertform.blade.php ENDPATH**/ ?>