<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view lender records</title>
    <style>
        body{
            font-size: 20px;
            background-color:#BCC8EC;
            
        }
        table{
            position: relative;
            top: 200px;
            border-collapse: collapse;
            margin: 0 auto;
            width: 200px;
            height: auto;
            border: 1px solid black;
        }
        th,td{
            padding: 10px;
            border: 10pxpx solid black;
        }
        tr:nth-child(even){
            background-color: dodgerblue;
        }
        tr:nth-child(even):hover{
            background-color: white;
        }
        </style>
</head>
<body>
    <table>
        <tr>
            <th>ID</th>
            <th>Applicantion ID</th>
            <th>Application Name</th>
            <th>Loan type</th>
            <th>Approval status</th>
            <th>Comments</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        <?php $__currentLoopData = $lmanagements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_lmanagement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($_lmanagement->applicationId); ?></td>
            <td><?php echo e($_lmanagement->applicationName); ?></td>
            <td><?php echo e($_lmanagement->loanType); ?></td>
            <td><?php echo e($_lmanagement->approvalStatus); ?></td>
            <td><?php echo e($_lmanagement->comments); ?></td>

            <td><a href="edit2/<?php echo e($_lmanagement->id); ?>"> Edit</a></td>
            <td><a href="delete2/<?php echo e($_lmanagement->id); ?>">Delete</a></td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href = "<?php echo e(route('LManageInsert')); ?>">
        <button class = "add-a-button">ADD LOAN </button>
    </a>
    <a href = "<?php echo e(route('Landingpage')); ?>">
        <button class = "add-a-button">GO BACK </button>
    </a>

</body>
</html><?php /**PATH C:\Users\NANDINI JOTHIBASU\LoanManagement\resources\views/LManage_list.blade.php ENDPATH**/ ?>