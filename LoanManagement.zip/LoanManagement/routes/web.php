<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BorrowerController;
use App\Http\Controllers\LenderController;
use App\Http\Controllers\LManageController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('Landingpage');
});
//Borrower

Route::get('/borrower', [App\Http\Controllers\BorrowerController::class, 'BorrowerList']);

Route::get('/', [BorrowerController::class, 'BorrowerInsertform']);
Route::post('/create', [BorrowerController::class, 'insert']);

Route::get('BorrowerInsertform', [App\Http\Controllers\BorrowerController::class, 'BorrowerInsertform'])->name('BorrowerInsertform');

Route::get('/Landingpage', function(){
    return view('Landingpage');
})->name('Landingpage');

Route::get('view-records-borrower', [BorrowerController::class, 'BorrowerList']);

Route::get('edit/{id}', [BorrowerController::class, 'edit']);
Route::post('edit/{id}', [BorrowerController::class, 'update']);

Route::get('delete/{id}', [BorrowerController::class, 'delete']);

//Lender

Route::get('/_lender', [App\Http\Controllers\LenderController::class, 'Lender_list']);

Route::get('/', [LenderController::class, 'LenderInsertform']);
Route::post('/create1', [LenderController::class, 'insert1']);

Route::get('LenderInsertform', [App\Http\Controllers\LenderController::class, 'LenderInsertform'])->name('LenderInsertform');


Route::get('view-records-_lender', [LenderController::class, 'Lender_list']);

Route::get('edit1/{id}', [LenderController::class, 'edit1']);
Route::post('edit1/{id}', [LenderController::class, 'update1']);

Route::get('delete1/{id}', [LenderController::class, 'delete1']);

//loanmanagement
Route::get('/_lmanagement', [App\Http\Controllers\LManageController::class, 'Lmanage_list']);

Route::get('/', [LManageController::class, 'LManageInsert']);
Route::post('/create2', [LManageController::class, 'insert2']);

Route::get('LManageInsert', [App\Http\Controllers\LManageController::class, 'LManageInsert'])->name('LManageInsert');


Route::get('view-records-_lmanagement', [LManageController::class, 'LManage_list']);

Route::get('edit2/{id}', [LManageController::class, 'edit2']);
Route::post('edit2/{id}', [LManageController::class, 'update2']);

Route::get('delete2/{id}', [LManageController::class, 'delete2']);

