<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('_lender', function (Blueprint $table) {
            $table->id();
            $table->string('name',50);
            $table->integer('dob');
            $table->integer('age');
            $table->string('gender',10);
            $table->string('address',50);
            $table->biginteger('phone');
            $table->integer('aadhar');
            $table->string('bank');
            $table->biginteger('account');
            $table->string('email',30);
            $table->string('loanType');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('_lender');
    }
};
